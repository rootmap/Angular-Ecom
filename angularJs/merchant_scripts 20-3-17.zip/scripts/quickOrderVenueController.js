/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global angular */
angular
        .module('merchantaj', ['angular-growl'])
        .controller('quickOrderVenueController', function ($scope, $http, growl) {
            //INSERT FUNCTION START HERE
            $scope.DatainsertQuick = function (quickOrderall) {
                console.log(quickOrderall);

                $http.post("./php/controller/quickorderVenueController.php", {'eventTitle': quickOrderall.eventTitle, 'vanueTitle': quickOrderall.vanueTitle, 'TCT': quickOrderall.TCT, 'ticketQuantity': quickOrderall.ticketQuantity})

                        .success(function (data, status, heards, config) {
                            if (data == 1)
                            {
                                growl.success("Data Insert Successfully", {title: ' '});
                            }
                            else
                            {
                                 growl.error("Failed, Please Try Again.", {title: ' '});
                            }
                        });


            } //INSERT FUNCTION START HERE



            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadQuickOrder = function () {
                $http.post("./php/controller/paymentMethodController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.EvntQkOrderData = data;
                });

            }
            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END
            $scope.loadQuickOrder();

            //CREATE FUNCTION TO  VENUE LOAD LIST DATA AUTOMATICALLY START
            $scope.loadQuickVenueList = function (evt) {

                $http.post("./php/controller/manualOrderVenueController.php", {'venue_event_id': evt}).success(function (data, status, heards, config) {
                    $scope.VenueQuickData = data;
                });

            }
            //$scope.loadoofflineChkVTList();
            //CREATE FUNCTION TO VENUE  LOAD LIST DATA AUTOMATICALLY END


            //CREATE FUNCTION TO  TICKET TYPE LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoofflineChkVTList = function (evts) {
                $http.post("./php/controller/manualOrderTickettypeController.php", {'evt': evts}).success(function (data, status, heards, config) {
                    $scope.ticketQuickData = data;
                });

            }
            //$scope.loadoofflineChkTCtypeList();
            //CREATE FUNCTION TO TICKET TYPE  LOAD LIST DATA AUTOMATICALLY END
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);//controller END here   