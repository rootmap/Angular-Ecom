/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular
        .module('merchantaj')
        .controller('dashboardController', function ($scope, $http) {
            /*Title show of Angular start Here*/
            $scope.eventname = "Total Events";
            $scope.totaleventplace = "0";
            $scope.totalsales = "Total Sales";
            $scope.totalsalesamount = "0";
            $scope.users = "Users";
            $scope.totalusers = "0";
            $scope.netbalance = "Net Balance";
            $scope.totalnetbalance = "0";
            $scope.refunds = "Refunds";
            $scope.refundsamount = "0";
            $scope.TotalOrder = "Total Order";
            $scope.TotalOrderAmount = "0";
            $scope.ticketList = "0";
            $scope.paymentmethod = "0";
            $scope.checkInmanagement = "0";

            /*Title show of Angular END Here*/


            //  DASHBORAD EVENT FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllEvent = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 1}).success(function (data, status, heards, config) {
//
//                    $scope.totaleventplace = data;
//
//                });
//            }
//
//            $scope.loadAllEvent();
            //DASHBORAD EVENT FUNCTION TO LOAD DATA END HERE




            //  DASHBORAD SALES FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllSales = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 2}).success(function (data, status, heards, config) {
//
//                    $scope.totalsalesamount = data;
//                });
//            }
//
//            $scope.loadAllSales();
            //DASHBORAD SALES FUNCTION TO LOAD DATA END HERE


            //  DASHBORAD USERS FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllUsers = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 3}).success(function (data, status, heards, config) {
//
//                    $scope.totalusers = data;
//                });
//            }
//
//            $scope.loadAllUsers();
            //DASHBORAD USERS FUNCTION TO LOAD DATA END HERE

            //  DASHBORAD NET BALANCE FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllNetBalance = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 4}).success(function (data, status, heards, config) {
//
//                    $scope.totalnetbalance = data;
//                });
//            }
//
//            $scope.loadAllNetBalance();
            //DASHBORAD NET BALANCE FUNCTION TO LOAD DATA END HERE

            //  DASHBORAD REFUND FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllRefund = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 5}).success(function (data, status, heards, config) {
//
//                    $scope.refundsamount = data;
//                });
//            }
//
//            $scope.loadAllRefund();
            //DASHBORAD REFUND FUNCTION TO LOAD DATA END HERE



            //  DASHBORAD  REGISTRATION FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllregistrationtotal = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 6}).success(function (data, status, heards, config) {
//
//                    $scope.TotalOrderAmount = data;
//                });
//            }
//
//            $scope.loadAllregistrationtotal();
            //DASHBORAD REGISTRATION FUNCTION TO LOAD DATA END HERE



            //  DASHBORAD TICKETS LIST FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllTicketList = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 7}).success(function (data, status, heards, config) {
//
//                    $scope.ticketList = data;
//                });
//            }
//
//            $scope.loadAllTicketList();
            //DASHBORAD TICKETS LIST FUNCTION TO LOAD DATA END HERE


            //  DASHBORAD PAYMENT METHOD FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllpaymentMethod = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 8}).success(function (data, status, heards, config) {
//
//                    $scope.paymentmethod = data;
//                });
//            }
//
//            $scope.loadAllpaymentMethod();
            //DASHBORAD  PAYMENT METHOD FUNCTION TO LOAD DATA END HERE


            //  DASHBORAD CHECK-IN MANAGEMENT FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllCheckInManagement = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 9}).success(function (data, status, heards, config) {
//
//                    $scope.checkInmanagement = data;
//                });
//            }
//
//            $scope.loadAllCheckInManagement();
            //DASHBORAD CHECK-IN MANAGEMENT FUNCTION TO LOAD DATA END HERE


            //CREATE FUNCTION TO DASHBORAD LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoEventAllDashboradList = function (param) {
                console.log(param);
                if (param == '')
                {
                    $scope.param = {};
                }
                else
                {
                    $scope.param = {'evt': param};
                }
                $http.post("./php/controller/eventTicketInfoSoldDashbordController.php", $scope.param).success(function (data, status, heards, config) {
                    
                    $scope.totaleventplace = data.lstevt;
                    $scope.totalsalesamount = data.totalsalesdata;
                    $scope.totalusers = data.usersdata;
                    $scope.totalnetbalance = data.totalnetdata;
                    $scope.refundsamount = data.refundsdata;
                    
                    $scope.TotalOrderAmount = data.TotalOrderAmount;
                    $scope.ticketList = data.ticketList;
                    $scope.paymentmethod = data.paymentmethod;
                    $scope.checkInmanagement = data.checkInmanagement;

                    //console.log(data);
                });

            }


            //CREATE FUNCTION TO DASHBORAD LOAD LIST DATA AUTOMATICALLY END






        });

