/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


angular
        .module('merchantaj', ['angular-growl'])
        .controller('partnersImgController', function ($scope, $http, $timeout, growl) {

            

            //CREATE TICKET TYPE FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadEvent = function () {
                $http.get("./php/controller/ticketListController.php").success(function (data, status, heards, config) {
                    $scope.Evntpaymtd = data;
                });
            }
            $scope.loadEvent();
            //CREATE TICKET TYPE FUNCTION TO LOAD LIST DATA AUTOMATICALLY END

            
            
            
//            $scope.loadPaymentmethodEdit = function (payEvent) {
//                $http.post("./php/controller/paymentMethodEditController.php", {'id': payEvent }).success(function (data, status, heards, config) {
//                    $scope.rows=[];
//                    $scope.event_id=payEvent;
//                    //extracting data for name and id and create st/status
//                    angular.forEach(data, function (value, key) {    
//                        $scope.rows.push({
//                            check_namest: value.pmst,
//                            check_name_ID:value.id,
//                            check_name:value.name
//                        });
//                        console.log(value.name);
//                    });
//                    console.log($scope.event_id);
//                });
//            }
//            
//            
//            $scope.AddPaymentMethod = function (eventId) {
//                
//            }
            
            
            ////////////////////////////////////////////
          // growl.success("Please wait a while! your image is processing", {title: ' '});
           
           $scope.imageUpload = function(event){
                
             var fiels = event.target.files;
             var file = fiels[fiels.length -1];
             $scope.file = file;
             var reader = new FileReader();
              growl.success("Please wait a while! your image is processing", {title: ' '});
             reader.onload = $scope.imageIsLoaded;
             reader.readAsDataURL(file);
             
         }
         
         $scope.imageIsLoaded = function (e) {
            
                $scope.$apply(function () {
                    $scope.openPic = true;
                    $scope.fullImage = e.target.result;
                     
                    if($scope.fullImage){
                        growl.success("Image upload successfully done", {title: ' '});
                       
//                         window.location.href='user_profile.php';
                    }else{ 
                         growl.error("There something is going wrong.", {title: ' '});
                    }
                    $scope.imagecover = e.target.result;

                   // $scope.upload($scope.fullImage);
                    

                });
          }
          
          $scope.clearCover = function ()
            {
                $scope.fullImage = '';
                $scope.openPic = false;
            }
            
         
          
            
//            $scope.upload = function (val) {
////                console.log('clicking');
//                if (val != null)
//                {
//                    $http.post("./php/controller/partner_imageController.php", {photo:val}).success(function (response) {
//                       
//                    });  
//                }
//            }
//           $scope.AddPartnerImage = function (tt_id,eid) {
           $scope.AddPartnerImage = function (eid) {
                //alert(eid);
//                if (tt_id != null && eid != null)
                if (eid != null)
                {
//                    $http.post("./php/controller/partner_imageController.php", {photo:$scope.fullImage,ticket_id:tt_id,event_id:eid}).success(function (data) {
                    $http.post("./php/controller/partner_imageController.php", {photo:$scope.fullImage,event_id:eid}).success(function (data) {
                        
                          if(data == 1){
                              growl.success("Insert successfully", {title: ' '});
                          }else if(data == 2){
                              growl.success("Updated successfully", {title: ' '});
                          }else{
                              growl.error("Something going wrong", {title: ' '});
                          }
                        
//                        growl.success("Image upload successfully done", {title: ' '});
//                        setTimeout(function(){  window.location.href='partnersImg.php'; }, 2000);
                       
                    });  
                }
                else{
                    growl.error("Select An Event", {title: ' '});
                }
                       
            }
           
            ////////////////////////////////////////////
            
       
            
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);