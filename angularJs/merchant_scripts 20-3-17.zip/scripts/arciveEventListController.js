/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global angular */
angular
        .module('merchantaj')
        .controller('arciveEventListController', function ($scope, $http, $timeout) {

            //CREATE FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadEventList = function () {
                $http.post("./php/controller/arciveEventListController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.eventlistdata = data;
                    console.log(data);
                });
            }
             $scope.loadEventList();
            //CREATE FUNCTION TO LOAD LIST DATA AUTOMATICALLY END


            //DELETE FUNCTION WORKING START HERE
            $scope.Deleteventlist = function (eventlist) {
                $http.post("./php/controller/arciveEventListDeleteController.php", {'event_id': eventlist}).success(function (data, status, heards, config) {
                    //$scope.companyData=data;
                    if (data == 1)
                    {
                        //TO LOAD LIST DATA AUTOMATICALLY START
                        $scope.loadEventList();
                        //TO LOAD LIST DATA AUTOMATICALLY END
                        growl.success("Deleted Successfully", {title: ' '});

                    } else
                    {
                        growl.error("Failed To Deleted", {title: ' '});
                    }
                });

            }// DELETE FUNCTION WORKING END HERE

        });//controller END here   