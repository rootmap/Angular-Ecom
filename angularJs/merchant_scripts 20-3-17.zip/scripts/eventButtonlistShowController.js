/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular
        .module('merchantaj', ['angular-growl'])
        .controller('eventButtonlistShowController', function ($scope, $http, growl) {


           // PAYMENT GETAWAY LIST LOAD LIST DATA AUTOMATICALLY START
            $scope.loadpaymentGetaway = function () {
                $http.post("./php/controller/eventButtonListShowController.php").success(function (data, status, heards, config) {
                    $scope.eventBtndata = data;
                    console.log(data);
                });
            }

            $scope.loadpaymentGetaway();
            //PAYMENT GETAWAY LIST  LOAD LIST DATA AUTOMATICALLY END



            // DELETE FUNCTION WORKING START HERE
//            $scope.DeleteQustionList= function (questionList) {
//                $http.post("./php/controller/questionListDeleteController.php", {'form_id': questionList})
//                        .success(function (data, status, heards, config) {
//                           // $scope.questionListdata = data;
//                            if (data == 1)
//                            {
//                                growl.success("Deleted Successfully", {title: ' '});
//                                //TO LOAD LIST DATA AUTOMATICALLY START
//                                 $scope.loadQuestionList();
//                                //TO LOAD LIST DATA AUTOMATICALLY END
//                            } else
//                            {
//                                 growl.error("Failed To Deleted", {title: ' '});
//                            }
//                        });
//
//            }// DELETE FUNCTION WORKING END HERE





        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);