/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


angular
        .module('merchantaj', ['angular-growl'])
        .controller('manualNewPickPointController', function ($scope, $http, $timeout, growl) {

            //INSERT DATA START HERE
            $scope.AddPaymentMethod = function (pickpoint)
            {
                //debug stage
              // console.log($scope.event_id);
//                console.log($scope.rows);
                //dubug stage end


                $http.post("./php/controller/manualNewPickPointController.php", {'event_id': pickpoint.eventValue, 'pointAddress':pickpoint.pointAddress,'pointContactdetailsAddress':pickpoint.pointContactdetailsAddress,'PickPointName':pickpoint.PickPointName})
                        .success(function (data, status, heards, config) {
                            if (data == 1)
                            {
                                growl.success("Pickup Point Save Successfully", {title: ' '});
                                window.location.href = 'pickPointList.php';
                            }
                            else if (data == 2)
                            {
                                growl.success("Pickup Point Updated Successfully", {title: ' '});
                                window.location.href = 'pickPointList.php';
                            }
                            else
                            {
                                growl.error("Insert Failed To Submit", {title: ' '});
                            }
                        });
            }
            //INSERT DATA START HERE

            //CREATE TICKET TYPE FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadEvent = function () {
                $http.get("./php/controller/paymentMethodController.php").success(function (data, status, heards, config) {
                    $scope.Evntpaymtd = data;
                });
            }
            $scope.loadEvent();
            //CREATE TICKET TYPE FUNCTION TO LOAD LIST DATA AUTOMATICALLY END

        
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);