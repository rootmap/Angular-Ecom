/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


angular
        .module('merchantaj',['angular-growl'])
        .controller('paymentMethodController', function ($scope, $http, $timeout, growl) {

            //INSERT DATA START HERE
            $scope.AddPaymentMethod = function ()
            {
                //debug stage
//                console.log($scope.event_id);
//                console.log($scope.rows);
                //dubug stage end
                
                
                
                $http.post("./php/controller/paymentMethodSaveController.php", {'event_id':$scope.event_id, 'param':$scope.rows})
                        .success(function (data, status, heards, config) {
                            if(data==1)
                            {
                                growl.success("Payment Method Save Successfully", {title: ' '});
                                growl.info("Redirecting to list page....", {title: ' '});
                                setTimeout(function(){
                                    window.location.href="./paymentMethodList.php";
                                },1000)
                                
                            }
                            else if(data==2)
                            {
                                growl.success("Payment Method Updated Successfully", {title: ' '});
                                growl.info("Redirecting to list page....", {title: ' '});
                                setTimeout(function(){
                                    window.location.href="./paymentMethodList.php";
                                },1000)
                            }
                            else
                            {
                                growl.error("Insert Failed To Submit", {title: ' '});
                            }
                });
            }
            //INSERT DATA START HERE

            //CREATE TICKET TYPE FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadEvent = function () {
                $http.get("./php/controller/paymentMethodController.php").success(function (data, status, heards, config) {
                    $scope.Evntpaymtd = data;
                });
            }
            $scope.loadEvent();
            //CREATE TICKET TYPE FUNCTION TO LOAD LIST DATA AUTOMATICALLY END

            //CHECKBOX DATA START HERE
            $scope.loadEventpayment = function () {
                $http.get("./php/controller/paymentMethodAllname.php").success(function (data, status, heards, config) {                    
                    //creating new array for ind payment method
                    $scope.rows=[];
                    
                    //extracting data for name and id and create st/status
                    angular.forEach(data, function (value, key) {
                        $scope.rows.push({
                            check_namest: '0',
                            check_name_ID:value.id,
                            check_name:value.name,
                            check_box:'false'
                        });
                        console.log(value.name);
                    });
                    //creating new array for ind payment method
                    
                });
            }
            //checkbox data start here
            $scope.loadEventpayment();
            //CHECKBOX DATA END HERE
            
            
            $scope.loadPaymentmethodEdit = function (payEvent) {
                $http.post("./php/controller/paymentMethodEditController.php", {'id': payEvent }).success(function (data, status, heards, config) {
                    $scope.rows=[];
                    $scope.event_id=payEvent;
                    //extracting data for name and id and create st/status
                    angular.forEach(data, function (value, key) {    
                        $scope.rows.push({
                            check_namest: value.pmst,
                            check_name_ID:value.id,
                            check_name:value.name
                        });
                        console.log(value.name);
                    });
                    console.log($scope.event_id);
                });
            }
            
       
            
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);