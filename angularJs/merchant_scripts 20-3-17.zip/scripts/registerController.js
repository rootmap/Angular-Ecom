/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular
        .module('merchantaj', ['angular-growl'])
        //Controller function start here
        .controller('registerController', function ($scope, $http, growl) {
            $scope.registerData = {};
            //Function Submit from start here.
            $scope.registerinsert = function (registerData) {

                console.log(registerData);

                if (registerData.CaptchaCode == registerData.captcha_code)
                {
                    if (registerData.password == registerData.confirmPassword)
                    {
                        //growl.success("Thanks, Your Captcha is correct. and passtoo", {title: ' '});
                        $http.post('./php/controller/registerController.php', {'firstName': registerData.firstName, 'lastName': registerData.lastName,
                            'email': registerData.email, 'yourAddress': registerData.yourAddress, 'password': registerData.password,
                            'phoneMobileNo': registerData.phoneMobileNo})
                                .success(function (data, status, heards, config) {
                                    if (data == 1)
                                    {
                                        growl.success("Thanks, Your organizer account created successfully.", {title: ' '});
                                        growl.info("Page is redirecting, Please be patient...", {title: ' '});
                                        $http.get('./email/merchentAccountCreation.php').success(function(data,status,heards,config){
                                            console.log('mail send');
                                        });
                                        setTimeout(function () {
                                            window.location.href = "dashboard.php";
                                        }, 1500);
                                    }
                                    else if (data == 0)
                                    {
                                        growl.warning("Field is empty, Please check all mandatory field.", {title: ' '});
                                    }
                                    else if (data == 2)
                                    {
                                        //$("#tab2").removeClass("active");
                                        $("#tab1").addClass("active");
                                        //$("#fns").css("display","none");
                                        //$("#nxt").removeAttr("style");
                                        //$("#nxt").removeClass("disabled");
                                        growl.warning("Email address already exists, please enter a new email and reset your password.", {title: ' '});
                                    }
                                    else if (data == 3)
                                    {
                                        growl.error("Failed to create your organizer account, Please try again or contact ticketchai support.", {title: ' '});
                                    }
                                    else if (data == 4)
                                    {
                                        growl.error("Failed to create your organizer info, Please try again or contact ticketchai support.", {title: ' '});
                                    }
                                });
                    }
                    else
                    {
                        growl.error("Failed Password Mismatch, Please Type Your Password Carefully.", {title: ' '});
                    }
                }
                else
                {
                    growl.error("Failed Captcha Mismatch, Please Type Correct Captcha.", {title: ' '});
                }
            }
            //Function Submit from end here.

//            function randomString(length, chars) {
//                var result = '';
//                for (var i = length; i > 0; --i)
//                    result += chars[Math.round(Math.random() * (chars.length - 1))];
//                return result;
//            }
//            document.write(randomString(6, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'));



            $scope.InitiateCaptche = function ()
            {
                $scope.text = "";
                $scope.possible = "ABCDEFGHIJKLMNPQRSTUVWXYZabcdefghijklmnpqrstuvwxyz123456789";

                for (var i = 0; i < 5; i++)
                    $scope.text += $scope.possible.charAt(Math.floor(Math.random() * $scope.possible.length));
                //return $scope.text;
                $scope.registerData['captcha_code'] = $scope.text;

            }

            $scope.InitiateCaptche();

            //console.log($scope.registerData);

            //show Field label code start here
            $scope.merchantUp = "Organizer Sign Up / Registration";
            $scope.Step01 = "Step01";
            $scope.Step02 = "Step - 02";
            $scope.Step03 = "Step - 03";
            $scope.RegistrationApproval = "Dear Organizer, Please Provide Your Credential - For Login / Registration Approval";
            $scope.FirstName = "First Name";
            $scope.LastName = "Last Name";
            $scope.Email = "Email";
            /**1st step end here***/

            /**2nd step start here**/
            $scope.YourAddress = "Your Address";
            $scope.Password = "Password";
            $scope.ConfirmPassword = "Confirm Password";
            $scope.PhoneMobileNo = "Phone/Mobile No.";
            $scope.CaptchaCode = "Captcha ";
            $scope.Back = "Back";
            $scope.Next = "Next";
            /**2nd step end here**/

            /**3rd step start here**/
            $scope.Finish = "Finish";
            $scope.thankYou = "Thank You!";
            /**3rd step end here**/
            //show Field label code END here

        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(4000);
        growlProvider.globalDisableCountDown(true);
    }]);//Controller function end here

