/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global angular */
angular
        .module('merchantaj', ['angular-growl'])
        .controller('manualOrderController', function ($scope, $http, growl) {
            //INSERT FUNCTION START HERE
            $scope.Datainsert = function(offLineCheck){
                console.log(offLineCheck);
                
                $http.post("./php/controller/manualOrderDataInsertController.php",{'eventTitle':offLineCheck.eventTitle,'vanueTitle':offLineCheck.vanueTitle,'TCT':offLineCheck.TCT,'ticketQuantity':offLineCheck.ticketQuantity,'customerFirstName':offLineCheck.customerFirstName,'customerLastName':offLineCheck.customerLastName,
                    'customerPhone':offLineCheck.customerPhone,'customerEmail':offLineCheck.customerEmail,'hmDelivery':offLineCheck.hmDelivery})
                        .success(function(data, status, heards, config){
                            growl.success("Data Insert Successfully.", {title: ' '});
                          //$scope.flyshow="Data Insert Successfully";
                            var obj =data;    
                            var ouid = obj.order_user_id;
                            $scope.orderSubmitEmail(ouid);
                });
                
                

                        
            } //INSERT FUNCTION START HERE
            
            $scope.orderSubmitEmail = function (order_user_id) {
                $http.post('email/ordersubmit_email.php', {o_u_id:order_user_id}).then(function (data) {
                });
            }

            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoofflineChkListdd = function () {
                $http.post("./php/controller/paymentMethodController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.EvntOffChk = data;
                });
            
            }
            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END
            $scope.loadoofflineChkListdd();

            //CREATE FUNCTION TO  VENUE LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoofflineChkVTList = function (evt) {

                $http.post("./php/controller/manualOrderVenueController.php", {'venue_event_id': evt}).success(function (data, status, heards, config) {
                    $scope.VenueData = data;
                });
              
            }
            //$scope.loadoofflineChkVTList();
            //CREATE FUNCTION TO VENUE  LOAD LIST DATA AUTOMATICALLY END
            
            
               //CREATE FUNCTION TO  TICKET TYPE LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoofflineChkTCtypeList = function (evt) {
                $http.post("./php/controller/manualOrderTickettypeController.php", {'evt':evt}).success(function (data, status, heards, config) {
                    $scope.ticketData = data;
                });
              
            }
            //$scope.loadoofflineChkTCtypeList();
            //CREATE FUNCTION TO TICKET TYPE  LOAD LIST DATA AUTOMATICALLY END
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);//controller END here   