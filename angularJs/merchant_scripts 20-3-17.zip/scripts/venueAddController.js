angular
        .module('merchantaj', ['angular-growl'])
        .controller('venueAddController', function ($scope, $http, growl) {
            $scope.venueAllData = [];
            //INSERT FUNCTION START HERE
            $scope.DataSave = function (venueAllData) {
                console.log(venueAllData);

                growl.info("Creating venue ticket please wait...", {title: ' '});
                $http.post("./php/controller/VenueDataInsertController.php", {'event': venueAllData.event, 'NameOfVenue': venueAllData.NameOfVenue,
                    'StreetLine': venueAllData.StreetLine, 'CityFrom': venueAllData.CityFrom, 'Country': venueAllData.Country})

                        .success(function (data, status, heards, config) {
                            growl.success("Insert Value Submit successfully", {title: ' '});
                            $http.post('./email/merchentVenueCreation.php', {'event': venueAllData.event, 'NameOfVenue': venueAllData.NameOfVenue}).success(function (data, status, heards, config) {
                                console.log('mail send');
                                growl.success("Thank You, Your venue ticket is created successfully.", {title: ' '});
                                growl.info("Redirecting...", {title: ' '});
                                // window.location.href = "ticket_list.php";
                            });

                            if (data == 1)
                            {
                                growl.success("Data Insert Successfully", {title: ' '});
                            } else if (data == 2)
                            {
                                $scope.flyshow = "Data Insert Falied";
                                growl.error("Data Insert Falied", {title: ' '});
                            }
                        });


            } //INSERT FUNCTION START HERE



            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoEventVenue = function () {
                $http.post("./php/controller/paymentMethodController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.VenueNewData = data;

                });

            }

            $scope.loadoEventVenue();
            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END


            //EDIT FUNCTION TO LOAD  EDIT DATA AUTOMATICALLY START
            $scope.LoadvenueEditList = function (venueList) {
                $http.post("./php/controller/VenueListEditController.php", {'venue_id': venueList}).success(function (data, status, heards, config) {
                    //$scope.venueListdata = data;
                    //UPDATE DATA 
                    $scope.update = true;
                    //UPDATE DATA 
                    $scope.venueAllData.venue_id = data[0].venue_id;
                    $scope.venueAllData.event = data[0].venue_event_id;
                    $scope.venueAllData.NameOfVenue = data[0].venue_title;
                    $scope.venueAllData.StreetLine = data[0].venue_description;
                    $scope.venueAllData.CityFrom = data[0].city;
                    $scope.venueAllData.Country = data[0].country;
                    console.log(data);
                });
            }

            // EDIT FUNCTION TO LOAD EDIT LIST DATA AUTOMATICALLY END

            $scope.AutoVarVal = function (id,df)
            {
                $scope.venueAllData[id] = df;
                //console.log(id);
                console.log($scope.venueAllData);

            }

            //UPDATE START HERE
            $scope.UpdateDataSave = function (venueAllData) {
                // console.log(fundMethod);
                $http.post("./php/controller/VenueDataInsertController.php", {'venue_id': venueAllData.venue_id, 'event': venueAllData.event, 'NameOfVenue': venueAllData.NameOfVenue,
                    'StreetLine': venueAllData.StreetLine, 'CityFrom': venueAllData.CityFrom, 'Country': venueAllData.Country})
                        .success(function (data, status, heards, config) {
                            if (data == 1)
                            {
                                growl.success("Successfully Update Data", {title: ' '});
                                //UPDATE DATA 
                                $scope.update = false;
                                //UPDATE DATA 

                            } else if (data == "2")
                            {
                                growl.error("Failed To Update Data", {title: ' '});
                            }

                        });//CREATE FUNCTION TO SAVE DATA INTO DATABASE END

            }//UPDATE END


        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);