/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj', ['angular-growl'])
        .controller('userListController', function ($scope, $http, growl) {





            //USER LIST FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadUserList = function () {
                $http.post("./php/controller/userListController.php").success(function (data, status, heards, config) {
                    $scope.userlistdata = data;
                });
            }
            $scope.loadUserList();
            //USER LIST FUNCTION TO LOAD LIST DATA AUTOMATICALLY 

            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoEventVenue = function () {
                $http.post("./php/controller/paymentMethodController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.VenueNewData = data;

                });

            }

            $scope.loadoEventVenue();
            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END


   
           // MODEL DATA EVENT WISE ORDER REPORT INSERT END HERE
           
           $scope.ModelDataReportDateWise = function (modelDataG) {
                console.log(modelDataG);
                if (modelDataG.event != null)
                {
                    $http.post("./php/controller/EvntWiseUserReportController.php", {'event': modelDataG.event})
                            .success(function (data, status, heards, config) {
                                $scope.userlistdata = data;
                            });
                }
            }
           
//         $scope.MEventWOrderReport=function(modelOrderReport){
//             consple.log(modelOrderReport);
//             $http.post("./php/controller/EvntWiseOrderReportController.php",{'eventwise':modelOrderReport.event})
//              .success(function (data, status, heards, config) {
//                                $scope.orderlistdata = data;
//                            });
//             
//         }
           
             // MODEL DATA EVENT WISE ORDER REPORT INSERT START HERE




        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);