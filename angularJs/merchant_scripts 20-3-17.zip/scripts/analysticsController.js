/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj')
        .controller('analysticsController', function ($scope, $http) {



            //  ANALYSTICS ORDER QUANTITY  SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllOrderQuantity = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 1}).success(function (data, status, heards, config) {

                    $scope.totalOrderQuantity = data;

                });
            }
            $scope.loadAllOrderQuantity();

            //  ANALYSTICS ORDER QUANTITY SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE



            //  ANALYSTICS TOTAL ORDER AMOUNT SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllOrderTotalOrderAmount = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 2}).success(function (data, status, heards, config) {

                    $scope.totalOrderAmountData = data;

                });
            }
            $scope.loadAllOrderTotalOrderAmount();

            //  ANALYSTICS TOTAL ORDER AMOUNT SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE



            //  ANALYSTICS REFUN REQUEST SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllRefundRequest = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 3}).success(function (data, status, heards, config) {

                    $scope.refundRequestData = data;

                });
            }
            $scope.loadAllRefundRequest();

            //  ANALYSTICS TOTAL REFUN REQUEST SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE


            //  ANALYSTICS TOTAL EVENT SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllTotalEvent = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 4}).success(function (data, status, heards, config) {

                    $scope.totalEventData = data;

                });
            }
            $scope.loadAllTotalEvent();

            //  ANALYSTICS TOTAL EVENT SEVEN DAY FUNCTION  TO LOAD  DATA  START HERE


            //  ANALYSTICS TOTAL ALL CUSTOMER FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllCustomer = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 5}).success(function (data, status, heards, config) {

                    $scope.Customer = data;

                });
            }
            $scope.loadAllCustomer();

            //  ANALYSTICS TOTAL ALL CUSTOMER FUNCTION  TO LOAD  DATA  START HERE



            //  ANALYSTICS TOTAL VISIT EVENTS FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllVisitEvents = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 6}).success(function (data, status, heards, config) {

                    $scope.visitevents = data;

                });
            }
            $scope.loadAllVisitEvents();

            //  ANALYSTICS TOTAL VISIT EVENTS FUNCTION  TO LOAD  DATA  START HERE




            //  ANALYSTICS TOTAL PAID ORDERS FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllVisitEvents = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 7}).success(function (data, status, heards, config) {

                    $scope.paidOrders = data;

                });
            }
            $scope.loadAllVisitEvents();

            //  ANALYSTICS TOTAL PAID ORDERS FUNCTION  TO LOAD  DATA  START HERE
            
            
            
            
            //  ANALYSTICS TOTAL PUBLISHED ALL EVENTS FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllPublishedAllEvents = function () {
                $http.post("./php/controller/analysticsController.php", {'event': 8}).success(function (data, status, heards, config) {

                    $scope.publishedAllEvents = data;

                });
            }
            $scope.loadAllPublishedAllEvents();

            //  ANALYSTICS TOTAL  PUBLISHED ALL EVENTS FUNCTION  TO LOAD  DATA  START HERE
            
            
            


            //TODAY EVENT START HERE
            $scope.boxTitle = "Total Order Quantity";
            $scope.totalOrderQuantity = "0";
//            $scope.Updatednow = "TODAY";

            $scope.TotalOrderAmount = "Total order Amount";
            $scope.totalOrderAmountData = "0";
//            $scope.Lastday = "TODAY";

            $scope.refund = "Total Refund Request";
            $scope.refundRequestData = "0";
//            $scope.Inthelasthour = "TODAY";

            $scope.Totalevent = "Total Event Found";
            $scope.totalEventData = "0";
//            $scope.Updatednow = "TODAY";
            //TODAY EVENT END HERE


            //ANALYSTICS  PERCENT START HERE
            $scope.Customer = "0";
            $scope.visitevents = "0";

            $scope.paidOrders = "0";
            $scope.publishedAllEvents = "0";
            //ANALYSTICS  PERCENT START HERE
            
            
            $scope.Monthlysalesstarget = "Monthly sales target";
            $scope.orders = "Orders";

            $scope.completed = "Completed";
            $scope.NewVisitors = "New Visitors";
            $scope.Outoftotalnumber = "Out of total number";
            $scope.subscriptions = "Subscriptions";
            $scope.Monthlynewsletter = "Monthly newsletter";
        });



     