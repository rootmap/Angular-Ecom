/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular
        .module('merchantaj')
        .controller('eventController', function ($scope, $http) {
            /*Title show of Angular start Here*/
           
           $scope.eventsdata = [];
            //  DASHBORAD NET BALANCE FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllActive = function (param) {
                $scope.loading = true;
                $scope.params='active';
                $scope.params_bg=' ';
                if(param==1)
                {
                    $scope.params='active';
                }else if(param==2)
                {
                    $scope.params='covered';
                    $scope.params_bg=' red_corner';
                }
                else if(param==3)
                {
                    $scope.params='draft';
                    $scope.params_bg=' blue_corner';
                }
                else if(param==4)
                {
                    $scope.params='upcoming';
                    $scope.params_bg=' blue_corner';
                }
                $http.post("./php/controller/eventsController.php", {'status': $scope.params}).success(function (data, status, heards, config) {
                    //console.log(data);
                    $scope.eventsdata = data;
                    $scope.loading = false;
                });
            }

            

            //$scope.loadAllNetBalance();
            //DASHBORAD NET BALANCE FUNCTION TO LOAD DATA END HERE


        });

