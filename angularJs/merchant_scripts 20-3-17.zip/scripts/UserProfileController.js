/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


angular
        .module('merchantaj')
        //Controller function start here
        .controller('userProfileController', function ($scope, $http) {
            $scope.usersData=[];
            //CREATE REFUND REQUEST DATA SHOW FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loaduserprofile = function (currentuserid) {
                $http.post("./php/controller/userListShowController.php",{'id':currentuserid}).success(function (data, status, heards, config) {
                    $scope.usersData = data;
                });
            }
            //CREATE REFUND REQUEST DATA SHOW FUNCTION TO LOAD LIST DATA AUTOMATICALLY END
        });