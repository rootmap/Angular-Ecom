/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global angular */

angular
        .module('merchantaj', ['angular-growl'])
        .controller('newrefundRequestListController', function ($scope, $http, $timeout, growl) {

            //   FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllRefund = function () {
                $http.get("./php/controller/refunRequestListController.php").success(function (data, status, heards, config) {

                    $scope.refundListdata = data;


                });
            }

            $scope.loadAllRefund();
            // FUNCTION TO LOAD DATA END HERE



            // DELETE FUNCTION WORKING START HERE
            $scope.DeleterefundList = function (refundList) {
                $http.post("./php/controller/refunRequestDeleteController.php", {'id': refundList}).success(function (data, status, heards, config) {
                    //$scope.payeventdata=data;
                    if (data == 1)
                    {
                        growl.success("Deleted Successfully", {title: ' '});
                        //TO LOAD LIST DATA AUTOMATICALLY START
                        $scope.loadAllRefund();
                        //TO LOAD LIST DATA AUTOMATICALLY END
                    } else
                    {
                        growl.error("Failed To Deleted", {title: ' '});
                    }
                });

            }// DELETE FUNCTION WORKING END HERE





        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);

