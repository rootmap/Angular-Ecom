/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular
        .module('merchantaj')
        .controller('orderListController', function ($scope, $http) {

            // MODEL DATA DATE WISE ORDER INSERT START HERE
            $scope.ModelDataReportDateWise = function (modelData) {
                console.log(modelData);
                var start_date = $("#start-date-order").val();
                var end_date = $("#end-date-order").val();

                if (start_date != null && end_date != null && modelData.event != null)
                {
                    $http.post("./php/controller/OrderDateWiseController.php", {'event': modelData.event, 'startdate': start_date, 'enddate': end_date})
                            .success(function (data, status, heards, config) {
                                $scope.orderlistdata = data;
                            });
                }
            }

            // MODEL DATA DATE WISE ORDER INSERT END HERE


            // MODEL DATA EVENT WISE ORDER REPORT INSERT END HERE

            $scope.MEventWOrderReport = function (modelDataG) {
                console.log(modelDataG);
                if (modelDataG.event != null)
                {
                    $http.post("./php/controller/EvntWiseOrderReportController.php", {'event': modelDataG.event})
                            .success(function (data, status, heards, config) {
                                $scope.orderlistdata = data;
                            });
                }
            }

//         $scope.MEventWOrderReport=function(modelOrderReport){
//             consple.log(modelOrderReport);
//             $http.post("./php/controller/EvntWiseOrderReportController.php",{'eventwise':modelOrderReport.event})
//              .success(function (data, status, heards, config) {
//                                $scope.orderlistdata = data;
//                            });
//             
//         }

            // MODEL DATA EVENT WISE ORDER REPORT INSERT START HERE



            //  LOAD ORDER LIST DATA AUTOMATICALLY START
            $scope.loadoOrderList = function () {
                $http.post("./php/controller/orderListController.php", {'order_id': 1}).success(function (data, status, heards, config) {
                    $scope.orderlistdata = data;
                });

            }
            $scope.loadoOrderList();
            //  LOAD ORDER LIST DATA AUTOMATICALLY END



            // DELETE FUNCTION WORKING START HERE
//            $scope.DeleteorderList = function (orderlist) {
//                $http.post("./php/controller/orderListDeleteController.php", {'order_id': orderlist }).success(function (data, status, heards, config) {
//                    //$scope.payeventdata=data;
//                    if (data == 1)
//                    {
//                        $scope.flyshow = "Order Data Deleted Successfully";
//                        //TO LOAD LIST DATA AUTOMATICALLY START
//                         $scope.loadoOrderList();
//                        //TO LOAD LIST DATA AUTOMATICALLY END
//                    } else
//                    {
//                        $scope.flyshow = " Order Data Failed To Deleted";
//                    }
//                });

            //          }
            // DELETE FUNCTION WORKING END HERE




            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoEventVenue = function () {
                $http.post("./php/controller/paymentMethodController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.VenueNewData = data;

                });

            }

            $scope.loadoEventVenue();
            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END





            //  LOAD ORDER LIST DATA DELETE FUNCTION START
            $scope.DeleteticketList = function () {
                $http.post("./php/controller/orderListDeleteController", {'order_id': 1}).success(function (data, status, heards, config) {
                    $scope.orderlistdata = data;
                });

            }
            $scope.loadoOrderList();
            //  LOAD ORDER LIST DATA DELETE FUNCTION  END
            $scope.oid = '';
            $scope.email = '';
            $scope.msg = '';
            $scope.BindOIDcEm = function (Eticket)
            {
                $scope.oid = Eticket;
                console.log(Eticket);
            }

            //E-Ticket send start
            $scope.sendmassage = function () {

                $http.post("./php/controller/e_ticketAndSmsSendContorller.php", {'etemail': $scope.email, 'message': $scope.msg, 'oid': $scope.oid})
                        .success(function (data, status, heards, config) {
                            if (data == 1) {
                                $scope.flyshow = "data send successfully";
                            } else if (data == 0) {
                                $scope.flyshow = "data send failed";
                            }


                        });
            }  //E-ticket end here

            //Attendees send Email Start Here
            $scope.attendeesEmailAll = '';
            $scope.attendeesEmailAll = 'Please Wait...';
            $scope.AllAttendeesEmail = function () {

                $http.post("./php/controller/allAttendeesForMerchent.php", {'id': 1})
                        .success(function (data, status, heards, config) {
                            console.log(data);

                            $scope.attendeesEmailAll = data;



                        });

            }

            $scope.AllAttendeesEmail();


            //Attendees send Email End Here



            //Atttendees data send start here
            $scope.attendeesEmailAll = '';
            $scope.attendeesmsgAll = '';
            $scope.SendMessageToAllAttendees = function () {
                //console.log(1);
                //alert(1);
                //alert($scope.attendeesmsgAll);
                $http.post("./php/controller/e_ticketAndSmsAllSendContorller.php", {'email': $scope.attendeesEmailAll, 'msg': $scope.attendeesmsgAll}).success(function (data, status, heards, config) {
                    $scope.VenueNewData = data;

                });
            }
            //$scope.attendeesSend ();
            //Attendees data send End here

        });

