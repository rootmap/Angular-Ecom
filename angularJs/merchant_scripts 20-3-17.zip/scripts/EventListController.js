/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global angular */

angular
        .module('merchantaj')
        .controller('EventListController', function ($scope, $http) {
            $scope.datalength = [];
            $scope.eventlistdata = "";
            
            // MODEL DATA DATE WISE ORDER INSERT START HERE
            $scope.ModelDataReportDateWise = function (modelData) {
                //console.log(modelData);
                var start_date = $("#start-date").val();
                var end_date = $("#end-date").val();

                if (start_date != null && end_date != null)
                {
                    $http.post("./php/controller/EventDateWiseController.php", {'startdate': start_date, 'enddate': end_date})
                            .success(function (data, status, heards, config) {
                                $scope.eventlistdata = data;
                            });
                }
            }

            // MODEL DATA DATE WISE ORDER INSERT END HERE


            //CREATE FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadEventList = function () {
                $http.post("./php/controller/eventListController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.eventlistdata = data;
                    //$scope.datalength.row=data.length;
                });
            }


            //CREATE FUNCTION TO LOAD LIST DATA AUTOMATICALLY END

            $scope.loadEventList();
            //$scope.datalength=$scope.loadEventList().length;
            //console.log($scope.datalength.row[0]);

            $scope.Deleteventlist = function (eventlist) {
                $http.post("./php/controller/eventListDeleteController.php", {'event_id': eventlist}).success(function (data, status, heards, config) {
                    //$scope.companyData=data;
                    if (data == 1)
                    {
                        //TO LOAD LIST DATA AUTOMATICALLY START
                        $scope.loadEventList();
                        //TO LOAD LIST DATA AUTOMATICALLY END
                        growl.success("Deleted Successfully", {title: ' '});

                    } else
                    {
                        growl.error("Failed To Deleted", {title: ' '});
                    }
                });

            }// DELETE FUNCTION WORKING END HERE

//            $scope.totaldata=$scope.loadEventList();
//            $scope.datalength=$scope.totaldata.length;
//            console.log($scope.datalength);

            //Field all Title show by angular End here 
        });//controller END here

