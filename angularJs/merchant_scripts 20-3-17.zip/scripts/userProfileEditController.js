/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj', ['angular-growl'])
        //Controller function start here
        .controller('userProfileEditController', function ($scope, $http, growl) {
            //Function Submit from start here.
            $scope.userinsert = function (userprofileData) {
                $http.post('./php/controller/userProfileUpdateController.php', {'username': userprofileData.username, 'emailaddress': userprofileData.emailaddress,
                    'firstName': userprofileData.firstName, 'lastName': userprofileData.lastName, 'address': userprofileData.address, 'city': userprofileData.city,
                    'country': userprofileData.country, 'postalCode': userprofileData.postalCode, 'company': userprofileData.company, 'password': userprofileData.password})
                        .success(function (data, status, heards, config) {


                            growl.success("Insert Value Submit successfully", {title: ' '});

                        });


            }//Function Submit from end here.




            //EDIT DATA START HERE
            $scope.loadusersEdit = function (userUID) {
                console.log(userUID);
                $http.post('./php/controller/userProfileEditController.php', {'id': userUID}).success(function (data, status, heards, config) {
                    //UPDATE DATA 
                    $scope.update = true;
                    //UPDATE DATA 
                    $scope.userUIDEdit.id = data[0].admin_id;
                    $scope.userUIDEdit.username = data[0].admin_user;
                    $scope.userUIDEdit.emailaddresss = data[0].admin_email;
                    $scope.userUIDEdit.firstName = data[0].admin_full_name;
                    $scope.userUIDEdit.lastName = data[0].admin_full_name;
                    $scope.userUIDEdit.address = data[0].admin_address;
                    $scope.userUIDEdit.city = data[0].admin_city;
                    $scope.userUIDEdit.country = data[0].admin_country;
                    $scope.userUIDEdit.postalCode = data[0].postal_code;
                    $scope.userUIDEdit.company = data[0].admin_company;
                    $scope.userUIDEdit.password = data[0].admin_password;
                    
                });
            }
            //EDIT DATA END HERE

            //UPDATE FUNCTION CODE START HERE
            $scope.UpdateUsaerData = function (userUIDEdit) {
                console.log(userUIDEdit);
                $http.post('./php/controller/userProfileUpdateController.php', {'username': userUIDEdit.username, 'emailaddress': userUIDEdit.emailaddresss,
                    'firstName': userUIDEdit.firstName, 'lastName': userUIDEdit.lastName, 'address': userUIDEdit.address, 'city': userUIDEdit.city,
                    'country': userUIDEdit.country, 'postalCode': userUIDEdit.postalCode, 'company': userUIDEdit.company, 'password': userUIDEdit.password})
                        .success(function (data, status, heards, config) {

                            if (data == 1)
                            {

//                                growl.success("Successfully Update Data", {title: ' '});
                                $http.get('./email/merchentUpdateAccount.php').success(function (data, status, heards, config) {
                                    console.log('mail send');
                                    //UPDATE DATA 
                                    $scope.update = false;
                                    growl.success("Thanks, Your merchant account Update successfully.", {title: ' '});
                                    
                                    //UPDATE DATA 
                                });
                            } else if (data == 2)
                            {
                                growl.error("Failed To Update Data", {title: ' '});
                            }

                        });


            }
            //UPDATE  FUNCTION CODE END HERE


            $scope.userUIDEdit = [];
            $scope.userUIDEdit.id = 0;
            //show Field label code start here
            $scope.PersonalDetails = "Personal/Profile Details";
            $scope.Username = "Username";
            $scope.Emailaddress = "Email address";
            $scope.FirstName = "First Name";
            $scope.LastName = "Last Name";
            $scope.Address = "Address";
            $scope.City = "City";
            $scope.Country = "Country";
            $scope.PostalCode = "Postal Code";
            $scope.Company = "Company";
            $scope.Password = "Password";
            $scope.saveProfile = "save Profile";
            $scope.UpdateProfile = "update Profile";

            //show Field label code END here
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);//Controller function end here
