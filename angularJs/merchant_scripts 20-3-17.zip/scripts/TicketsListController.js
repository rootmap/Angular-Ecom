angular
        .module('merchantaj', ['angular-growl'])
        .controller('TicketListCon', function ($scope, $http, $timeout, growl) {

            //   FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadTicketsList = function () {
                $http.get("./php/controller/ticketListController.php").success(function (data, status, heards, config) {
                    $scope.ticketListdata = data;
                });
            }

            $scope.loadTicketsList();
            // FUNCTION TO LOAD DATA END HERE

            $scope.DeleteticketList = function (ticketList) {
//                var c = confirm("Are your sure to delete this ticket?");
//                if (c == true)
//                {
                    $http.post("./php/controller/ticketListDeleteController.php", {'TT_id': ticketList}).success(function (data, status, heards, config) {
                        //$scope.companyData=data;
                        if (data == 1)
                        {
                             growl.success("Deleted Successfully", {title: ' '});
                            //TO LOAD LIST DATA AUTOMATICALLY START
                            $scope.loadTicketsList();
                            //TO LOAD LIST DATA AUTOMATICALLY END
                        } else
                        {
                            growl.error("Failed To Deleted", {title: ' '});
                        }
                    });
                //}

            }// DELETE FUNCTION WORKING END HERE



        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);