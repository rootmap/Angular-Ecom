/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


angular
        .module('merchantaj', ['angular-growl'])
        .controller('paymentMethodControllerList', function ($scope, $http, $timeout, growl) {

            //CREATE PAYMENT METHOD FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadPaymentmethodList = function () {
                $http.get("./php/controller/paymentMethodListShow.php").success(function (data, status, heards, config) {
                    $scope.payeventdata = data;
                    console.log(data);
                });
            }

            $scope.loadPaymentmethodList();
            //CREATE PAYMENT METHOD FUNCTION TO LOAD LIST DATA AUTOMATICALLY END
            
            
          // DELETE FUNCTION WORKING START HERE
            $scope.DeletepayList = function (payEvent) {
                $http.post("./php/controller/paymentMethodDeleteController.php", {'pay_id': payEvent }).success(function (data, status, heards, config) {
                    //$scope.payeventdata=data;
                    if (data == 1)
                    {
                        growl.success("Deleted Successfully", {title: ' '});
                        //TO LOAD LIST DATA AUTOMATICALLY START
                         $scope.loadPaymentmethodList();
                        //TO LOAD LIST DATA AUTOMATICALLY END
                    } else
                    {
                         growl.error("Failed To Deleted", {title: ' '});
                    }
                });

            }// DELETE FUNCTION WORKING END HERE

        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);