/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


angular
        .module('merchantaj', ['angular-growl'])
        .controller('paymentMethodofflineList', function ($scope, $http, $timeout, growl) {

            //CREATE PAYMENT METHOD FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadPaymentmethodOfflineList = function () {
                $http.get("./php/controller/paymentMethodofflineListShow.php").success(function (data, status, heards, config) {
                    $scope.payOfflinedata = data;
                    console.log(data);
                });
            }

            $scope.loadPaymentmethodOfflineList();
            //CREATE PAYMENT METHOD FUNCTION TO LOAD LIST DATA AUTOMATICALLY END
            
            
          // DELETE FUNCTION WORKING START HERE
            $scope.DeletepayOffList = function (paymethodOff) {
                $http.post("./php/controller/paymentMethodOfflinelListDataDelete.php", {'payoff_id': paymethodOff }).success(function (data, status, heards, config) {
                    //$scope.payeventdata=data;
                    if (data == 1)
                    {
                         //TO LOAD LIST DATA AUTOMATICALLY START
                            $scope.loadPaymentmethodOfflineList();
                        //TO LOAD LIST DATA AUTOMATICALLY END
                        growl.success("Deleted Successfully", {title: ' '});
                       
                    } else
                    {
                        growl.error("Failed To Deleted", {title: ' '});
                    }
                });

            }// DELETE FUNCTION WORKING END HERE

        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);