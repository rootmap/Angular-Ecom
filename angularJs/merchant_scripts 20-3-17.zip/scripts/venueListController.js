/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
angular
        .module('merchantaj', ['angular-growl'])
        .controller('venueListController', function ($scope, $http,growl) {

            //  LOAD VENUE LIST DATA AUTOMATICALLY START
            $scope.loadVenuelist = function () {
                $http.post("./php/controller/venueListDataShowController.php", {'venue_id': 1}).success(function (data, status, heards, config) {
                    $scope.venueListdata = data;
                });

            }
            $scope.loadVenuelist();
            //  LOAD VENUE LIST DATA AUTOMATICALLY END



            // DELETE FUNCTION WORKING START HERE
           $scope.DeleteVenueList = function (venueList) {
              $http.post("./php/controller/venueDeleteListController.php", {'venue_id': venueList}).success(function (data, status, heards, config) {
                 // $scope.venueListdata = data;
                   if (data == 1)
                    {
                        growl.success("Venue Data Deleted Successfully", {title: ' '});
                        
                       //TO LOAD LIST DATA AUTOMATICALLY START
                     $scope.loadVenuelist();
                       //TO LOAD LIST DATA AUTOMATICALLY END
                    }
                    else
                   {
                        growl.error("Venue Data Failed To Deleted", {title: ' '});
                    }
                });
                
            }
            
            // DELETE FUNCTION WORKING END HERE
 }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);

