/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj', ['angular-growl'])
        .controller('addQuestionsController', function ($scope, $http, growl) {

            $scope.addSingelData = function(offLineCheck) {
                //INSER DATA START HERE
                //console.log(offLineCheck);
                if (offLineCheck.eventTitle != null)
                {
                    $http.post("./php/controller/addQuestionsController.php", {'eventTitle': offLineCheck.eventTitle})

                            .success(function (data, status, heards, config) {
                                growl.success("Data Insert Successfully", {title: ' '});
                                //console.log(data);
                            });//INSER DATA END HERE
                }
                else
                {
                    growl.info("Please select an event", {title: ' '});
                }

            }
            
            $scope.makeDefEvent=function(id)
            {
                $scope.addSingelData["eventTitle"]=id;
                console.log(id);
            }

            $scope.addSingelDataandMore = function (offLineCheck) {
                //INSER DATA START HERE
                if (offLineCheck.eventTitle != null)
                {
                    $http.post("./php/controller/addQuestionsController.php", {'eventTitle': offLineCheck.eventTitle})

                            .success(function (data, status, heards, config) {
                                if (data == 1)
                                {
                                    growl.success("Data Insert Successfully", {title: ' '});
                                    setTimeout(function () {
                                        window.location.href = "add_more_questions.php?event_id=" + offLineCheck.eventTitle;
                                    }, 1500);
                                }
                                else
                                {
                                    growl.error("Failed, Please Try Again.", {title: ' '});
                                }
                                //console.log(data);
                            });//INSER DATA END HERE
                }
                else
                {
                    growl.info("Please select an event", {title: ' '});
                }

            }


            $scope.addskipData = function (offLineCheck) {
                //INSER DATA START HERE
                if (offLineCheck.eventTitle != null)
                {
                    growl.info("Please wait we are processing your data.", {title: ' '});
                    setTimeout(function () {
                        window.location.href = "add_more_questions.php?event_id=" + offLineCheck.eventTitle;
                    }, 1500);
                }
                else
                {
                    $scope.flyshow = "";
                    growl.info("Please select an event", {title: ' '});
                }

            }



            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoofflineChkListdd = function () {
                $http.post("./php/controller/paymentMethodController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.EvntOffChk = data;
                    console.log(data);
                });

            }
            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END
            $scope.loadoofflineChkListdd();



            $scope.TicketsDetails = "Let's Add Your Event Question/Custom Field Details";
            $scope.NameMandatory = "Name (Mandatory)";
            $scope.EmailMandatory = "Email (Mandatory)";
            $scope.AddMoreQuestions = "Save & Add More Questions";
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);
