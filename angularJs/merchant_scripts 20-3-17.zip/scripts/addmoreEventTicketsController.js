/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj')
        .controller('addmoreEventTicketsController', function ($scope){
            $scope.title = "Let's Add Your Ticket Details";
            $scope.ticket ="Ticket";
            $scope.EntryPass="Entry Pass";
            $scope.AddAnotherTicket="Add Another Ticket";
            $scope.submit="Submit";
        });
