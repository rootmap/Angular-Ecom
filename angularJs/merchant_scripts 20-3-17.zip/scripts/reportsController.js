/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj')
        .controller('reportsController', function ($scope, $http) {
            $scope.salesReports = "0";

            $scope.custom_evt = "";
            //  REPORTS EVENT FUNCTION  TO LOAD  DATA  START HERE
            $scope.loadAllEvent = function () {
                $http.post("./php/controller/reports_1Controller.php", {'reports': 1}).success(function (data, status, heards, config) {

                    $scope.salesReports = data;

                });
            }

            $scope.loadAllEvent();
            //REPORTS EVENT FUNCTION TO LOAD DATA END HERE



            //  LOAD EVENT ORDER LIST DATA AUTOMATICALLY START
            $scope.loadreportslist = function () {
                $http.post("./php/controller/reportsController.php").success(function (data, status, heards, config) {
                    $scope.reportslistData = data;
                });

            }
            $scope.loadreportslist();
            //  LOAD  EVENT ORDER LIST DATA AUTOMATICALLY END


//            //  LOAD ORDER LIST DATA AUTOMATICALLY START
//            $scope.loadreportslist = function () {
//                $http.post("./php/controller/reportsController.php").success(function (data, status, heards, config) {
//                    $scope.reportslistData = data;
//                });
//
//            }
//            $scope.loadreportslist();
//            //  LOAD ORDER LIST DATA AUTOMATICALLY END




            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoEventAllList = function (param) {
                console.log(param);
                if (param == '')
                {
                    $scope.param = {};
                }
                else
                {
                    $scope.param = {'date': param};
                }
                $http.post("./php/controller/eventTicketInfoSoldController.php", $scope.param).success(function (data, status, heards, config) {
                    $scope.alleventdata = data.lstevt;
                    $scope.totalSales = data.salesdata;
                    $scope.NetEarnings = data.netearningsdata;
                    $scope.Refunds = data.refundsdata;
                    $scope.Refunds_remain = data.refundsremaindata;
                    $scope.Registration = data.userdata;
                    console.log(alleventdata);
                });

            }
            
            $scope.loadoEventWiseList = function (evtparam,param) {
                console.log(param);
                if (param == '')
                {
                    $scope.param = {};
                }
                else
                {
                    $scope.param = {'date': param,'evt':evtparam};
                }
                $http.post("./php/controller/eventTicketInfoSoldController.php", $scope.param).success(function (data, status, heards, config) {
                    //custom_evt
                    $scope.alleventdata = data.lstevt;
                    $scope.totalSales = data.salesdata;
                    $scope.NetEarnings = data.netearningsdata;
                    $scope.Refunds = data.refundsdata;
                    $scope.Refunds_remain = data.refundsremaindata;
                    $scope.Registration = data.userdata;
                    //console.log(data.lstevt[0].event_title);
                    $scope.custom_evt=data.lstevt[0].event_title;
                });

            }
            
            $scope.loadoEventWiseDateList = function (evtparam,param,paramd) {
                //console.log(param);
                if (param == '')
                {
                    $scope.param = {};
                }
                else
                {
                    $scope.param = {'startdate': param,'enddate': paramd,'evt':evtparam};
                }
                $http.post("./php/controller/eventTicketInfoSoldController.php", $scope.param).success(function (data, status, heards, config) {
                    //custom_evt
                    $scope.alleventdata = data.lstevt;
                    $scope.totalSales = data.salesdata;
                    $scope.NetEarnings = data.netearningsdata;
                    $scope.Refunds = data.refundsdata;
                    $scope.Refunds_remain = data.refundsremaindata;
                    $scope.Registration = data.userdata;
                    //console.log(data.lstevt[0].event_title);
                    $scope.custom_evt=data.lstevt[0].event_title;
                });

            }


            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END

            //Total Aomunt show start here
            $scope.totalSales = "0";
            $scope.NetEarnings = "0";
            $scope.RemainingToTransfer = "0";
            $scope.Refunds = "0";
            $scope.Registration = "0";




            //  DASHBORAD SALES FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllSales = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 2}).success(function (data, status, heards, config) {
//
//                    $scope.totalSales = data;
//                });
//            }
//
//            $scope.loadAllSales();
            //DASHBORAD SALES FUNCTION TO LOAD DATA END HERE



            //  DASHBORAD NET BALANCE FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllNetBalance = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 4}).success(function (data, status, heards, config) {
//
//                    $scope.NetEarnings = data;
//                });
//            }
//
//            $scope.loadAllNetBalance();
            //DASHBORAD NET BALANCE FUNCTION TO LOAD DATA END HERE



            //  DASHBORAD REFUND FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllRefund = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 5}).success(function (data, status, heards, config) {
//
//                    $scope.Refunds = data;
//                });
//            }
//
//            $scope.loadAllRefund();
            //DASHBORAD REFUND FUNCTION TO LOAD DATA END HERE





            //  DASHBORAD USERS FUNCTION  TO LOAD  DATA  START HERE
//            $scope.loadAllUsers = function () {
//                $http.post("./php/controller/dashboardController.php", {'event': 3}).success(function (data, status, heards, config) {
//
//                    $scope.Registration = data;
//                });
//            }
//
//            $scope.loadAllUsers();
            //DASHBORAD USERS FUNCTION TO LOAD DATA END HERE




            //Total Amount show end here


        });



     