/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global angular */

angular
        .module('merchantaj')
        .controller('attendeesReportController', function ($scope, $http) {
            $scope.datalength = [];
            $scope.attendlistdata = "";

            // MODEL DATA DATE WISE ORDER INSERT START HERE
            $scope.ModelDataReportDateWise = function (modelData) {
                
                var start_date = $("#start-date-order").val();
                var end_date = $("#end-date-order").val();
                console.log(modelData);
		
                if (start_date != null && end_date != null)
                {
                    $http.post("./php/controller/attendeesDateWiseReportController.php", {'event': modelData.event, 'startdate': start_date, 'enddate': end_date})
                            .success(function (data, status, heards, config) {
                                $scope.attendlistdata = data;
                            });
                }
            }

            // MODEL DATA DATE WISE ORDER INSERT END HERE


            //CREATE FUNCTION TO  EVENT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadoEventVenue = function () {
                $http.post("./php/controller/paymentMethodController.php", {'event_id': 1}).success(function (data, status, heards, config) {
                    $scope.VenueNewData = data;

                });

            }

            $scope.loadoEventVenue();
            //CREATE FUNCTION TO EVENT  LOAD LIST DATA AUTOMATICALLY END


            //CREATE FUNCTION TO LOAD ATTENDEES REPORT LIST DATA AUTOMATICALLY START
            $scope.loadattendtList = function () {
                $http.post("./php/controller/attendeesReportController.php").success(function (data, status, heards, config) {
                    $scope.attendlistdata = data;
                    //$scope.datalength.row=data.length;
                });
            }


            //CREATE FUNCTION TO LOAD ATTENDEES REPORT LIST DATA AUTOMATICALLY END

            $scope.loadattendtList();
            //$scope.datalength=$scope.loadEventList().length;
            //console.log($scope.datalength.row[0]);
//
//            $scope.Deleteventlist = function (eventlist) {
//                $http.post("./php/controller/eventListDeleteController.php", {'event_id': eventlist}).success(function (data, status, heards, config) {
//                    //$scope.companyData=data;
//                    if (data == 1)
//                    {
//                        //TO LOAD LIST DATA AUTOMATICALLY START
//                        $scope.loadEventList();
//                        //TO LOAD LIST DATA AUTOMATICALLY END
//                        growl.success("Deleted Successfully", {title: ' '});
//
//                    } else
//                    {
//                        growl.error("Failed To Deleted", {title: ' '});
//                    }
//                });
//
//            }// DELETE FUNCTION WORKING END HERE

//            $scope.totaldata=$scope.loadEventList();
//            $scope.datalength=$scope.totaldata.length;
//            console.log($scope.datalength);

            //Field all Title show by angular End here 
        });//controller END here

