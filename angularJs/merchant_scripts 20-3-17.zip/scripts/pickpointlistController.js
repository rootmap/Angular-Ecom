/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global angular */

angular
        .module('merchantaj', ['angular-growl'])
        .controller('pickpointlistController', function ($scope, $http, $timeout, growl) {

            // PICK POINT LOAD LIST DATA AUTOMATICALLY START
            $scope.loadPickPointList = function () {
                $http.post("./php/controller/pickPointListController.php").success(function (data, status, heards, config) {
                    $scope.pickPointListdata = data;
                    console.log(data);
                });
            }

            $scope.loadPickPointList();
            //PICK POINT  TO LOAD LIST DATA AUTOMATICALLY END



            // DELETE FUNCTION WORKING START HERE
            $scope.DeletepickPointList = function (pickPointList) {
                $http.post("./php/controller/pickpointDeleteListController.php", {'id': pickPointList})
                        .success(function (data, status, heards, config) {
                            // $scope.questionListdata = data;
                            if (data == 1)
                            {
                                growl.success("Deleted Successfully", {title: ' '});
                                //TO LOAD LIST DATA AUTOMATICALLY START
                                $scope.loadPickPointList();
                                //TO LOAD LIST DATA AUTOMATICALLY END
                            } else
                            {
                                growl.error("Failed To Deleted", {title: ' '});
                            }
                        });

            }// DELETE FUNCTION WORKING END HERE





        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);