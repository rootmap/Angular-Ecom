/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj', ['angular-growl'])
        // controller start here
        .controller('addMoreQuestionsController', function ($scope, $http, growl) {

            $scope.adqc = {};

//            $scope.mmv = [];

            $scope.rows = [];

            $scope.counter = 1;

            $scope.addRow = function () {

                //$scope.rows.push($scope.counter);
                $scope.rows.push({
                    id: $scope.counter,
                    rein: 'requ' + $scope.counter, //data send time title show and count number show
                    qt: '',
                    ft: '',
                    ep: 'no',
                    vd: 'no'
                });
                $scope.counter++;

                console.log($scope.rows);
            }



            $scope.addRow();


            $scope.AddAllQCData = function ()
            {
                $scope.dataparam = $scope.rows;
                if ($scope.EventId != null)
                {
                    $http.post("./php/controller/addMoreQuestionsController.php", {'data': $scope.dataparam, 'event_id': $scope.EventId})
                            .success(function (data, status, heards, config) {
                                if (data == 1)
                                {
                                    $scope.flyshow = "";
                                    growl.success("Data Insert Successfully", {title: ' '});
                                    //console.log(data);
                                }
                                else
                                {
                                    $scope.flyshow = "";
                                    growl.error("Data Failed To Insert", {title: ' '});
                                }

                            });//Database data send php start here 
                    console.log($scope.rows);
                }
                else
                {
                    growl.warning("Something went wrong, Please goto back page and select event.", {title: ' '});
                }
            }






            //Inputbox data function start here
            $scope.morequstion = function () {



                $scope.question.push({
                    name: $scope.name
                });

                console.log($scope.question);

                //Database data send php start here
                $http.post("./php/controller/addMoreQuestionsController.php", {'qustiontitle': addMoreQustion.qustiontitle, 'QuestionType': addMoreQustion.QuestionType,
                    'Showfollowingtickets': addMoreQustion.Showfollowingtickets, 'Required': addMoreQustion.Required, 'Optional': addMoreQustion.Optional})
                        .success(function (data, status, heards, config) {
                            growl.success("Data Insert Successfully", {title: ' '});

                        });//Database data send php start here 
            } //Inputbox data function end here


            //EDIT FUNCTIONS START HERE
            $scope.loadQuestionEditdata = function (questionList) {
                $http.post("./php/controller/questionListEditController.php", {'from_id': questionList})
                        .success(function (data, status, heards, config) {
                            $scope.rows = [];
                            $scope.counter = 1;
                            $scope.update = true;
                            //extracting data for name and id and create st/status
                            angular.forEach(data, function (value, key) {

                                $scope.rows.push({
                                    id: $scope.counter,
                                    rein: 'requ' + $scope.counter, //data send time title show and count number show
                                    qt: value.form_field_title,
                                    ft: value.form_field_type,
                                    ep: value.entry_pass,
                                    vd: value.form_field_is_required
                                });
                                $scope.counter++;

                                console.log(value.name);
                            });
                            //creating new array for ind payment method
                        });

            }

            //EDIT FUNCTIONS END HERE


            //update code start from here 
            $scope.AddAllQCDataUpdate = function ()
            {
                if ($scope.EventId != null)
                {
                    $scope.dataparam = $scope.rows;
                    $http.post("./php/controller/moreQuestionsUpdateController.php", {'data': $scope.dataparam, 'event_id': $scope.EventId})
                            .success(function (data, status, heards, config) {
                                if (data == 1)
                                {
                                    growl.success("Data Updated Successfully", {title: ' '});
                                    //console.log(data);
                                }
                                else
                                {
                                    growl.error("Data Failed To Update", {title: ' '});
                                }

                            });//Database data send php start here 
                    console.log($scope.rows);
                }
                else
                {
                    growl.warning("Something went wrong, Please goto back page and select event.", {title: ' '});
                }

            }
            //update code ends here


            //Input field Title show start here
            $scope.headeTitle = "Let's Add Your Ticket Details";
            $scope.QuestionTitle = "Question Title";
            $scope.QuestionType = "Question Type";
            $scope.Showfollowingtickets = "Show this question for the following tickets";
            $scope.EntryPass = "Entry Pass";
            $scope.QuestionStatus = "Question Status";
            $scope.required = "Required";
            $scope.optional = " Optional";
            $scope.AddMoreQuestions = "Add More Questions";
            $scope.Submit = "Submit";
            //Input field Title show End here
        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);// controller end here