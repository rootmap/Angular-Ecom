/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

angular
        .module('merchantaj', ['angular-growl'])
        .controller('paymentGetwayChargesController', function ($scope, $http, growl) {

            $scope.paymentgetawayListAll = function (paymentGetway) {
                // console.log=(eventButton);
                $http.post("./php/controller/paymentGetwayChargesInsertController.php", {'event_id': paymentGetway.event_id, 'payGateway': paymentGetway.payway})
                        .success(function (data, status, heards, config) {
                            if (data == 1)
                            {
                                growl.success("Thanks, Save Successfully.", {title: ' '});
                                setTimeout(function () {

                                    window.location.href = 'paymentGetwayChargesServicesList.php';
                                }, 2000);
                            } else if (data == 2)
                            {
                                growl.success("Thanks, Updated Successfully.", {title: ' '});
                                setTimeout(function () {

                                    window.location.href = 'paymentGetwayChargesServicesList.php';
                                }, 2000);
                            } else if (data == 3)
                            {
                                growl.error("Field is empty, please select event and button label.", {title: ' '});
                            } else
                            {
                                growl.error("Something went wrong, Please try again later.", {title: ' '});
                            }
                        });
            }
            //INSERT DATA START HERE



            //CREATE EVENT  FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.loadEvent = function () {
                $http.post("./php/controller/paymentMethodController.php").success(function (data, status, heards, config) {
                    $scope.Evntpaymtd = data;
                });
            }
            $scope.loadEvent();
            //CREATE EVENT  FUNCTION TO LOAD LIST DATA AUTOMATICALLY 


            //CREATE PAYMEMNT METHOD GATEWAY SERVICE LIST FUNCTION TO LOAD LIST DATA AUTOMATICALLY START
            $scope.LoadPaymentGateway = function () {
                $http.get('./php/controller/paymentGatewayController.php').success(function (data, status, heards, config) {
                    $scope.paygatewaymtd = data;
                    //console.log(data);
                });
            }
            $scope.LoadPaymentGateway();
            //CREATE PAYMEMNT METHOD GATEWAY SERVICE LIST FUNCTION TO LOAD LIST DATA AUTOMATICALLY END


        }).config(['growlProvider', function (growlProvider) {
        growlProvider.globalTimeToLive(3000);
        growlProvider.globalDisableCountDown(true);
    }]);