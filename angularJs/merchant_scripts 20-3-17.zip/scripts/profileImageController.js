/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* global angular */

angular
        .module('merchantaj', ['angular-growl'])
        .directive('fileInput', function ($parse) {
            return{
                restrict: 'A',
                link: function (scope, elem, attrs) {
                    elem.bind('change', function () {
                        $parse(attrs.fileInput).assign(scope, elem[0].files);
                        scope.$apply();
                    });
                }
            }
        })

        .controller('profileImageController', function ($scope, $http, $timeout, growl) {

            $scope.imageUpload = function (event) {
                var files = event.target.files; //FileList object 
                var file = files[files.length - 1];
                $scope.file = file;
                var reader = new FileReader();
                reader.onload = $scope.imageIsLoaded;
                reader.readAsDataURL(file);
            }

             
         $scope.imageIsLoaded = function (e) {
                $scope.$apply(function () {
                    $scope.openPic = true;
                    $scope.fullImage = e.target.result;
                    
                    if($scope.fullImage){
                        growl.success("Image upload successfully done.", {title: ' '});
                       
//                         window.location.href='user_profile.php';
                    }else{ 
                         growl.error("There something is going wrong.", {title: ' '});
                    }
                    $scope.imagecover = e.target.result;

                    $scope.upload($scope.fullImage);
                    

                });
          }
          

             $scope.clearCover = function ()
            {
                $scope.fullImage = '';
                $scope.openPic = false;
            }


             $scope.imageUpload_thumble = function (event) {
                var files = event.target.files; //FileList object 
                var file = files[files.length - 1];
                $scope.file = file;
                var reader = new FileReader();
                reader.onload = $scope.imageIsLoaded_thumble;
                reader.readAsDataURL(file);
            }
            
            $scope.imageIsLoaded_thumble = function (e) {
                $scope.$apply(function () {
                    $scope.goCats_thumble = true;
                    $scope.step_thumble = e.target.result;
                    $scope.imagethumble = e.target.result;
                });
            }
            
            $scope.clearThumble = function ()
            {
                $scope.imagethumble = '';
                $scope.goCats_thumble = false;
            }


//            $scope.upload = function (imagecover) {
////                var name = $scope.name;
//                //console.log('clicking');
//                if (imagecover != null)
//                {
//                    $http.post("./php/controller/profileImageController.php", {'photo': imagecover}).success(function (response) {
////                        console.log(data);
//                        growl.info("Redirecting.......", {title: ' '});
//                        setTimeout(function(){  window.location.href='user_profile.php'; }, 2000);
//                    });
//                }
//            }
            
            
             $scope.upload = function (val) {

                if (val != null)
                {
                    $http.post("./php/controller/profileImageController.php", {'photo': val}).success(function (response) {
                        //location.reload();
                        growl.info("Redirecting.......", {title: ' '});
                        setTimeout(function(){  window.location.href='user_profile.php'; }, 2000);
                       
                    });  
                }
            }





            //Field all Title show by angular End here 
        }).config(['growlProvider', function (growlProvider) {
//        growlProvider.globalTimeToLive(3000);
//        growlProvider.globalDisableCountDown(true);
    }]);//controller END here




            
           
            
           
            
         